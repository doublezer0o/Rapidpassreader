Rapid Reader Android NFC Reader (Starter)

এই প্রজেক্ট native Android NFC reader. প্রথম সংস্করণে কার্ডের UID ও NFC technology list দেখাবে। এটি কোনো protected card command চালায় না এবং ব্যালেন্স/যাত্রার ইতিহাস পড়ে না।

APK build করার ফোন-only পদ্ধতি:
1. ZIP ফাইলটি Android ফোনে ডাউনলোড করে Extract করুন।
2. GitHub-এ নতুন public/private repository তৈরি করুন (যেমন RapidReader)।
3. Extract করা ফোল্ডারের ভেতরের ফাইল/ফোল্ডারগুলো repository-তে আপলোড করুন; root-এ settings.gradle, build.gradle, app/ এবং .github/ থাকবে।
4. Actions tab > Build Rapid Reader APK workflow > Run workflow (বা main-এ push করলে automatic build হবে)।
5. Actions-এ সফল run খুলে Artifacts থেকে RapidReader-debug-apk ডাউনলোড করুন, unzip করে app-debug.apk ইনস্টল করুন।

APK debug-signed; private-use/testing-এর জন্য। পরবর্তী update-এ একই signing key/package id ব্যবহার করে release signing সেট করা উচিত।
