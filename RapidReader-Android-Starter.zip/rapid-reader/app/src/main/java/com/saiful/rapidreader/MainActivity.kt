package com.saiful.rapidreader

import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.*
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity(), NfcAdapter.ReaderCallback {
    private var adapter: NfcAdapter? = null
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var scanCard: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = NfcAdapter.getDefaultAdapter(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 34, 28, 24)
            setBackgroundColor(0xFFF2F6F8.toInt())
        }
        val title = TextView(this).apply {
            text = "Rapid Reader"
            textSize = 28f
            setTextColor(0xFF173B4B.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Rapid Pass NFC • Card inspection"
            textSize = 16f
            setTextColor(0xFF4B626E.toInt())
            setPadding(0, 8, 0, 18)
        }
        scanCard = TextView(this).apply {
            text = "📳\n\nকার্ডটি ফোনের NFC অংশে ধরুন\n\nস্ক্যানের জন্য প্রস্তুত"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(0xFF17664F.toInt())
            setPadding(20, 34, 20, 34)
            setBackgroundColor(0xFFE0F0EB.toInt())
        }
        status = TextView(this).apply {
            text = if (adapter == null) "এই ফোনে NFC অ্যাডাপ্টার পাওয়া যায়নি" else if (adapter?.isEnabled == true) "NFC চালু • কার্ড স্ক্যানের অপেক্ষায়" else "NFC বন্ধ • Settings থেকে চালু করুন"
            textSize = 16f
            setTextColor(0xFF1C6249.toInt())
            setPadding(0, 20, 0, 16)
        }
        val heading = TextView(this).apply {
            text = "স্ক্যান ফলাফল"
            textSize = 21f
            setTextColor(0xFF173B4B.toInt())
            setPadding(0, 14, 0, 8)
        }
        details = TextView(this).apply {
            text = "এখনো কোনো কার্ড স্ক্যান করা হয়নি।\n\nএই প্রাথমিক সংস্করণে UID, NFC প্রযুক্তি এবং প্রযুক্তি-সংক্রান্ত প্রকাশ্য তথ্য দেখানো হবে। সুরক্ষিত ব্যালেন্স বা যাত্রার তথ্য পড়ার চেষ্টা করা হবে না।"
            textSize = 16f
            setTextColor(0xFF344955.toInt())
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(scanCard)
        root.addView(status)
        root.addView(heading)
        root.addView(details)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val nfc = adapter ?: return
        if (!nfc.isEnabled) return
        val flags = NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V or
                NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK
        nfc.enableReaderMode(this, this, flags, null)
    }

    override fun onPause() {
        adapter?.disableReaderMode(this)
        super.onPause()
    }

    override fun onTagDiscovered(tag: Tag) {
        val uid = tag.id?.joinToString("") { "%02X".format(it) } ?: "Unavailable"
        val techs = tag.techList.map { it.substringAfterLast('.') }.distinct().joinToString("\n• ")
        val info = buildString {
            appendLine("Card UID")
            appendLine(uid)
            appendLine()
            appendLine("Detected NFC technologies")
            appendLine("• $techs")
            val iso = IsoDep.get(tag)
            if (iso != null) {
                appendLine()
                appendLine("ISO-DEP available")
                appendLine("Max transceive: ${iso.maxTransceiveLength} bytes")
            }
            appendLine()
            append("Note: UID/technology details only. Secure card balance and journey history are not read.")
        }
        runOnUiThread {
            status.text = "কার্ড স্ক্যান সফল ✓"
            scanCard.text = "✓\n\nকার্ড শনাক্ত হয়েছে\n\nআরেকটি কার্ড স্ক্যান করতে আবার ট্যাপ করুন"
            details.text = info
        }
    }
}
