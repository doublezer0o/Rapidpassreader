package com.saiful.rapidreader

import android.app.Activity
import android.app.AlertDialog
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.NfcF
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), NfcAdapter.ReaderCallback {
    private var adapter: NfcAdapter? = null
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var scanCard: TextView
    private lateinit var historyView: TextView
    private lateinit var balanceView: TextView
    private val prefs by lazy { getSharedPreferences("rapid_reader", MODE_PRIVATE) }
    private val trips = mutableListOf<String>()

    private fun card(title: String, body: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(18, 18, 18, 18)
        setBackgroundColor(0xFFFFFFFF.toInt())
        val t = TextView(this@MainActivity).apply { text = title; textSize = 20f; setTextColor(0xFF173B4B.toInt()); setPadding(0,0,0,10) }
        addView(t); addView(body)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, 14); layoutParams = lp
    }
    private fun txt(text: String, size: Float = 16f, color: Int = 0xFF344955.toInt()) = TextView(this).apply { this.text=text; textSize=size; setTextColor(color) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = NfcAdapter.getDefaultAdapter(this)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,24,18,20); setBackgroundColor(0xFFF2F6F8.toInt()) }
        root.addView(txt("Rapid Reader", 30f, 0xFF173B4B.toInt()))
        root.addView(txt("Rapid Pass NFC • Card inspection 0.2", 17f, 0xFF4B626E.toInt()).apply { setPadding(0,8,0,16) })
        scanCard = txt("📳\n\nকার্ড ফোনের NFC অংশে ধরুন\n\nস্ক্যানের অপেক্ষায়", 20f, 0xFF17664F.toInt()).apply { gravity=Gravity.CENTER; setPadding(16,32,16,32); setBackgroundColor(0xFFE0F0EB.toInt()) }
        root.addView(scanCard)
        status = txt("NFC পরীক্ষা করা হচ্ছে…", 16f, 0xFF1C6249.toInt()).apply { setPadding(0,18,0,12) }; root.addView(status)
        details = txt("কার্ড স্ক্যান করলে NFC-F/FeliCa-র উপলব্ধ metadata এখানে দেখাবে।", 16f).apply { setPadding(18,18,18,18) }
        root.addView(card("কার্ডের NFC তথ্য", details))
        balanceView = txt("লাইভ ব্যালেন্স NFC থেকে পড়া হয় না। চাইলে সর্বশেষ জানা ব্যালেন্স এখানে নিজের নোট হিসেবে লিখে রাখতে পারো।",16f)
        val balanceInput = EditText(this).apply { hint="নিজে জানা ব্যালেন্স লিখুন"; inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(prefs.getString("balance_note", "")) }
        val saveBal = Button(this).apply { text="ব্যালেন্স নোট সংরক্ষণ"; setOnClickListener { prefs.edit().putString("balance_note", balanceInput.text.toString()).apply(); balanceView.text="ম্যানুয়ালি সংরক্ষিত ব্যালেন্স: ${balanceInput.text} (NFC থেকে পড়া নয়)"; Toast.makeText(this@MainActivity,"সংরক্ষিত",Toast.LENGTH_SHORT).show() } }
        val balanceBox = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; addView(balanceView); addView(balanceInput); addView(saveBal) }
        root.addView(card("ব্যালেন্স নোট", balanceBox))
        val addTrip = Button(this).apply { text="+ যাত্রা নিজে যোগ করুন"; setOnClickListener { addTripDialog() } }
        historyView = txt("",16f)
        val historyBox = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; addView(addTrip); addView(historyView) }
        root.addView(card("যাত্রার নোট / History", historyBox)); refreshTrips()
        root.addView(txt("সতর্কতা: এই অ্যাপ কার্ডের সুরক্ষিত ব্যালেন্স বা পূর্ববর্তী যাত্রা স্বয়ংক্রিয়ভাবে পড়ে না। এখানে সংরক্ষিত তথ্য আপনার নিজস্ব ম্যানুয়াল নোট।",14f,0xFF657681.toInt()).apply { setPadding(4,8,4,8) })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun addTripDialog() {
        val station = EditText(this).apply { hint="স্টেশন / যাত্রার বিবরণ" }
        val fare = EditText(this).apply { hint="ভাড়া (টাকা)"; inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,8,24,0); addView(station); addView(fare) }
        AlertDialog.Builder(this).setTitle("যাত্রা যোগ করুন (ম্যানুয়াল)").setView(layout).setNegativeButton("বাতিল",null).setPositiveButton("সংরক্ষণ") { _,_ ->
            if(station.text.isNotBlank()) { val stamp=SimpleDateFormat("dd MMM yyyy, HH:mm",Locale.getDefault()).format(Date()); trips.add(0,"$stamp | ${station.text} | ভাড়া: ${fare.text.ifBlank { "—" }} টাকা"); saveTrips(); refreshTrips() }
        }.show()
    }
    private fun saveTrips(){ prefs.edit().putString("trips",trips.joinToString("\n")).apply() }
    private fun refreshTrips(){ if(!::historyView.isInitialized) return; val saved=prefs.getString("trips","").orEmpty(); trips.clear(); if(saved.isNotBlank()) trips.addAll(saved.split("\n")); historyView.text=if(trips.isEmpty()) "এখনো কোনো যাত্রা সংরক্ষণ করা হয়নি।" else trips.joinToString("\n\n") }
    override fun onResume(){ super.onResume(); val nfc=adapter ?: return; if(!nfc.isEnabled){status.text="NFC বন্ধ • Settings থেকে চালু করুন";return}; val flags=NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK; nfc.enableReaderMode(this,this,flags,null); status.text="NFC চালু • কার্ড স্ক্যানের অপেক্ষায়" }
    override fun onPause(){ adapter?.disableReaderMode(this); super.onPause() }
    override fun onTagDiscovered(tag: Tag){ val uid=tag.id?.joinToString(""){ "%02X".format(it) } ?: "Unavailable"; val techs=tag.techList.map{it.substringAfterLast('.')}.distinct().joinToString("\n• "); val nf=NfcF.get(tag)
        val info=buildString { appendLine("Card UID / ID: $uid"); appendLine(); appendLine("Detected NFC technologies:"); appendLine("• $techs"); if(nf!=null){ appendLine(); appendLine("NFC-F / FeliCa details"); appendLine("System Code: ${nf.systemCode?.joinToString(""){"%02X".format(it)} ?: "Not exposed"}"); appendLine("Manufacturer / PMm: ${nf.manufacturer?.joinToString(""){"%02X".format(it)} ?: "Not exposed"}"); appendLine("Max transceive: ${nf.maxTransceiveLength} bytes") }; appendLine(); append("এই metadata-ই Android-এর প্রকাশ্য tag API থেকে পাওয়া তথ্য। Protected balance বা journey data পড়া হয়নি.") }
        runOnUiThread{ status.text="কার্ড স্ক্যান সফল ✓"; scanCard.text="✓\n\nকার্ড শনাক্ত হয়েছে\n\nআরেকটি কার্ড স্ক্যান করতে ট্যাপ করুন"; details.text=info }
    }
}
